"""
@author Victor Valenzuela M
@since 28-12-22
"""

from .logger import Priority
from .logger import Error
from .logger import Warning
from .logger import Logger